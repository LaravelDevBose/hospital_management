<?php
/**
 * Created by PhpStorm.
 * User: Arup
 * Date: 12/8/2018
 * Time: 11:56 AM
 */

Class MY_Controller extends CI_Controller{

}
